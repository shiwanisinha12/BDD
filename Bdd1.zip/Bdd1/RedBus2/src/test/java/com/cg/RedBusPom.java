package com.cg;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RedBusPom {

	@FindBy(how=How.CSS,using="#src")
	WebElement from;
	
	@FindBy(xpath="//*[@id=\"search\"]/div/div[1]/div/ul/li[5]")
	WebElement fromClick;
	
	@FindBy(id="dest")
	WebElement to;


}


