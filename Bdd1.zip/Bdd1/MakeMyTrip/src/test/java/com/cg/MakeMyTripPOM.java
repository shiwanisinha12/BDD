package com.cg;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MakeMyTripPOM {

	
	@FindBy(id="header_tab_hotels")
	WebElement hotel;
	
	@FindBy(how=How.CSS,using="#hp-widget__sDest")
	WebElement city;
	
	//*[@id="ui-id-52"]/div/p[1]/span[1]
	
	
	@FindBy(id="ui-id-68")
	WebElement selectCity;
	
	@FindBy(id="hp-widget__chkIn")
	WebElement chkIn;
	
	
	@FindBy(xpath="//*[@id=\"dp1533618222774\"]/div/div[1]/table/tbody/tr[2]/td[4]/span")
	WebElement checkIn;
	
	@FindBy(id="hp-widget__chkOut")
	WebElement chkOut;
	
	@FindBy(xpath="//*[@id=\"dp1533620645466\"]/div/div[1]/table/tbody/tr[2]/td[6]")
	WebElement checkOut;
	
	@FindBy(id="hp-widget__paxCounter")
	WebElement rooms;
	
	@FindBy(xpath="//*[@id=\"js-addGuestRoom\"]")
	WebElement addRooms;
	
	
	@FindBy(xpath="//*[@id=\"js-adult_counter\"]/li[4]")
	WebElement numberOfPesrons;
	
	@FindBy(xpath="//*[@id=\"js-child_counter\"]/li[1]")
	WebElement noOfChild;
	
	@FindBy(xpath="//*[@id=\"allPaxAge\"]/div/ul/li[5]")
	WebElement age;
	
	@FindBy(xpath="//*[@id=\"js-filterOptins\"]/div/div[4]/p/a")
	WebElement done;
}


