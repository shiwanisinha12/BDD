package com.cg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MakeMyTripStep {
	
	WebDriver driver=null;
	MakeMyTripPOM page;
	
	@Before
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\shiwansi\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com/");
		page=PageFactory.initElements(driver, MakeMyTripPOM.class);
	}
	
	@Given("^I want to book a hotel$")
	public void i_want_to_book_a_hotel() throws Throwable {
	
	Thread.sleep(3000);
	page.hotel.click();

	}

	@Given("^I enter the city as (.*)$")
	public void i_enter_the_city_as_Goa(String arg) throws Throwable {
	
	page.city.clear();
	page.city.sendKeys(arg);
	//Thread.sleep(3000);  
	 // page.selectCity.click();
	  
	}

	@Given("^I select the checkin and checkout$")
	public void i_select_the_checkin_and_checkout() throws Throwable {
		page.chkIn.click();
		page.checkIn.click();
		page.chkOut.click();
		
	}

	@Then("^I edit the rooms$")
	public void i_edit_the_rooms() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		page.rooms.click();
		page.addRooms.click();
		page.numberOfPesrons.click();
		page.age.click();
		page.done.click();
	}

	@When("^I click on search$")
	public void i_click_on_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^I get a list of hotels$")
	public void i_get_a_list_of_hotels() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  
	}


}
