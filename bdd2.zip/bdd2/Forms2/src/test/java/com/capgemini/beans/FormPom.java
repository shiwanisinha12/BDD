package com.capgemini.beans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class FormPom {

	@FindBy(id="txt1")
	public WebElement username;
	
	
	@FindBy(id="txt2")
	public WebElement password;
	
	@FindBy(id="btn")
	public WebElement signin;
	
	@FindBy(name="name")
	public WebElement names;
	
	@FindBy(id="course")
	public WebElement course;
	
	public void selectCourse(int index)
	{
		Select select=new Select(course);
		select.selectByIndex(index);
	}
	@FindBy(name="gender")
	public List<WebElement> gender;
	
	@FindBy(name="hobbies")
	public List<WebElement> hobbies;
	
	
	
	
	
}
