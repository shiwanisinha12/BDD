package com.capgemini.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.beans.FormPom;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionForm {

	WebDriver driver = null;
	FormPom form;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\shiwansi\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D:\\BDD\\Forms\\src\\main\\webapp\\login.html");
		form = PageFactory.initElements(driver, FormPom.class);
	}

	@Given("^I enter the username as (.*)$")
	public void i_enter_the_username_as_abc(String arg) throws Throwable {
		form.username.sendKeys(arg);
		Thread.sleep(1000);
	}

	@Given("^I enter the password as (.*)")
	public void i_enter_the_password_as_Shiwani(String arg) throws Throwable {
		form.password.sendKeys(arg);
		Thread.sleep(1000);
		assertEquals("Login", driver.getTitle());
	}

	@When("^I click on sign in$")
	public void i_click_on_sign_in() throws Throwable {
		form.signin.click();
		Thread.sleep(1000);
	}

	@Then("^I get a message as wrong username$")
	public void i_get_a_message_as_wrong_username() throws Throwable {
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		assertEquals("Please enter correct username", alert.getText());
		driver.close();
	}

	@Then("^I get a message as wrong password$")
	public void i_get_a_message_as_wrong_password() throws Throwable {
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		assertEquals("Please enter correct password", alert.getText());
		driver.close();
	}

	@Then("^I get the success page$")
	public void i_get_the_success_page() throws Throwable {
		System.out.println("login successful");

		form.names.sendKeys("Shiwani");
		Thread.sleep(1000);
		form.selectCourse(1);
		Thread.sleep(1000);
		form.gender.get(1).click();
		assertEquals(true, form.gender.get(1).isSelected());
		Thread.sleep(1000);
		int length = form.hobbies.size();
		for (int element = 0; element < length; element++) {
			if (form.hobbies.get(element).isSelected()) {
				form.hobbies.get(element).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			}
		}
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(1000);
		form.hobbies.get(1).click();
		Thread.sleep(1000);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		form.hobbies.get(2).click();
		Thread.sleep(1000);
		driver.close();
	}

	@Given("^I am on login page$")
	public void i_am_on_login_page() throws Throwable {
		System.out.println("login page");
	}

	@When("^I click on sign in without entering username$")
	public void i_click_on_sign_in_without_entering_username() throws Throwable {
		form.username.sendKeys("");
		Thread.sleep(1000);
		form.signin.click();
	}

	@Then("^I get a message as username cant be empty$")
	public void i_get_a_message_as_username_cant_be_empty() throws Throwable {
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		assertEquals("Username cant be empty", alert.getText());
		driver.switchTo().alert().dismiss();

	}

	@When("^I click on sign in without entering password$")
	public void i_click_on_sign_in_without_entering_password() throws Throwable {

		form.username.sendKeys("shiwani");
		form.password.sendKeys("");
		Thread.sleep(1000);
		form.signin.click();
	}

	@Then("^I get a message as password cant be empty$")
	public void i_get_a_message_as_password_cant_be_empty() throws Throwable {

		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		assertEquals("Please enter correct password", alert.getText());
		driver.close();
	}

}
